from fastapi import FastAPI
from pydantic import BaseModel
import pandas as pd
import numpy as np
import joblib, json
from pathlib import Path

BASE = Path(__file__).resolve().parent
model = joblib.load(BASE/'modelo_valoracion.joblib')
meta = json.loads((BASE/'resultados_tfm.json').read_text(encoding='utf-8'))
app = FastAPI(title='Motor de Valoración Inmobiliaria', version='1.0')

class Vivienda(BaseModel):
    CITY: str
    CONSTRUCTEDAREA: float
    ROOMNUMBER: float
    BATHNUMBER: float
    CADCONSTRUCTIONYEAR: float
    CADMAXBUILDINGFLOOR: float
    CADDWELLINGCOUNT: float
    CADASTRALQUALITYID: float
    DISTANCE_TO_CITY_CENTER: float
    DISTANCE_TO_METRO: float
    LONGITUDE: float
    LATITUDE: float
    HASTERRACE: float = 0
    HASLIFT: float = 0
    HASAIRCONDITIONING: float = 0
    AMENITYID: float = 3
    HASPARKINGSPACE: float = 0
    HASNORTHORIENTATION: float = 0
    HASSOUTHORIENTATION: float = 0
    HASEASTORIENTATION: float = 0
    HASWESTORIENTATION: float = 0
    HASBOXROOM: float = 0
    HASWARDROBE: float = 0
    HASSWIMMINGPOOL: float = 0
    HASDOORMAN: float = 0
    HASGARDEN: float = 0
    ISDUPLEX: float = 0
    ISSTUDIO: float = 0
    ISINTOPFLOOR: float = 0
    FLOORCLEAN: float | None = None
    FLATLOCATIONID: float | None = None
    BUILTTYPEID_1: float = 0
    BUILTTYPEID_2: float = 0
    BUILTTYPEID_3: float = 1

@app.get('/health')
def health():
    return {'status':'ok','modelo':meta['modelo_final']}

@app.post('/predict')
def predict(v: Vivienda):
    d = v.model_dump()
    d['BUILDING_AGE'] = max(0, 2018 - d['CADCONSTRUCTIONYEAR'])
    d['AREA_PER_ROOM'] = d['CONSTRUCTEDAREA'] / max(d['ROOMNUMBER'], 1)
    max_floor = d['CADMAXBUILDINGFLOOR'] if d['CADMAXBUILDINGFLOOR'] not in (0,None) else None
    d['FLOOR_RATIO'] = None if max_floor is None or d['FLOORCLEAN'] is None else d['FLOORCLEAN']/max_floor
    d['NEAR_METRO_500M'] = int(d['DISTANCE_TO_METRO'] <= 0.5)
    amenity_cols = ['HASTERRACE','HASLIFT','HASAIRCONDITIONING','HASPARKINGSPACE','HASBOXROOM','HASWARDROBE','HASSWIMMINGPOOL','HASDOORMAN','HASGARDEN']
    d['AMENITIES_COUNT'] = sum(float(d.get(c,0) or 0) for c in amenity_cols)
    X = pd.DataFrame([{c:d.get(c) for c in meta['features']}])
    pred = float(np.expm1(model.predict(X))[0])
    q = float(meta['p90_abs_error_eur'])
    return {'precio_estimado_eur': round(pred,2), 'intervalo_empirico_90':[round(max(0,pred-q),2),round(pred+q,2)], 'modelo':meta['modelo_final']}
