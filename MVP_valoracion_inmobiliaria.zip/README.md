# Motor de Valoración Inmobiliaria

Modelo final: XGBoost + Optuna

## Ejecutar API
`uvicorn api:app --reload`

Swagger: `http://127.0.0.1:8000/docs`

## Ejecutar Streamlit
`streamlit run streamlit_app.py`

## Aviso
MVP académico entrenado con precios de oferta de 2018 para Madrid y Barcelona. No sustituye una tasación oficial.
